#include "Arduino.h"

#ifndef EYW_alt_H
#define EYW_alt_H

//constants used for i2c communication with the altimeter
#define BMP180_ADDR 0x77 // 7-bit address
#define	BMP180_REG_CONTROL 0xF4
#define	BMP180_REG_RESULT 0xF6
#define	BMP180_COMMAND_TEMPERATURE 0x2E
#define	BMP180_COMMAND_PRESSURE0 0x34
#define	BMP180_COMMAND_PRESSURE1 0x74
#define	BMP180_COMMAND_PRESSURE2 0xB4
#define	BMP180_COMMAND_PRESSURE3 0xF4
//constants used for i2c communication with the altimeter

static const int debounce = 200;	//used to debounce the pushbutton
static unsigned long elapsed = 0; 	//used to debounce the pushbutton

//constants for retrieving accelerometer axis values (may not be needed)
static const char xAxis = 'x';		
static const char yAxis = 'y';
static const char zAxis = 'z';


//Main class EYW_alt contains all sensor classes
class EYW_alt
{
	public:
		class Altimeter
		//The Altimeter class is used to control the BMP180 pressure sensor
		//and uses code from Sparkfuns library https://github.com/sparkfun/BMP180_Breakout
		{
			public:
			//all public function and variables are available for you to call and use in your sketch

				char begin();
				// call .begin() to initialize BMP180 before use
				// returns 1 if success, 0 if failure (bad component or I2C bus shorted?)
				// defaults to the button pin # 2, LED on pin # 4 and the speaker on # 5
				
				char begin(int bP, int lP, int sP);
				// call .begin() to initialize BMP180 before use
				// returns 1 if success, 0 if failure (bad component or I2C bus shorted?)
				// inputs for button pin (bP), LED pin (lP), and speaker pin (sP)

				char calibrate(int num);
				//call .calibrate() to calibrate zero height using 'num' numbers of readings

				char calibrate(int num, float filterVal);
				// call .calibrate() to calibrate zero height, optionally provide
				// 'filterVal' to set the Low Pass Filter from 0.0-1.0 (1.0 is no filtering) 

				void alarm(void);
				// sound the alarm on speakerPin. Default is 2x at 880 Hz for 250 mS

				void alarm(int num, int freq, int dur);
				//sound the alarm on num number of times at 'freq' frequency, for duration dur
				
				void led(int status);
				//controls the LED on the defined led pin # takes an argument of true/HIGH/1 and false/LOW/0

				float getHeight(void);
				// call .getHeight to use the sensors temperature and pressure readings
				// to determine your current altitude. .calibrate() must be called first
				// for accurate readingsconstants used for i2c communication with the altimeter

				float getHeightAvg(int num);
				// call .getHeightAvg(#) to average 'num' number of .getHeight() calls
				// usefull for more accurate readings


			private:
			//all private functions and variables cannot be accessed from your sketch

				char startTemperature(void);
				// command BMP180 to start a temperature measurement

                		char getTemperature(float &T);
				// return temperature measurement from previous startTemperature command
				// places returned value in T variable (deg C)
				// returns 1 for success, 0 for fail

				char startPressure(char oversampling);
				// command BMP180 to start a pressure measurement
				// oversampling: 0 - 3 for oversampling value

				char getPressure(float &P, float &T);
				// return absolute pressure measurement from previous startPressure command
				// note: requires previous temperature measurement in variable T
				// places returned value in P variable (mbar)
				// returns 1 for success, 0 for fail

				float sealevel(float P, float A);
				// convert absolute pressure to sea-level pressure (as used in weather data)
				// P: absolute pressure (mbar), A: current altitude (meters)
				// returns sealevel pressure in mbar. This is used for calibrating your zero height

				float altitude(float P, float P0);
				// convert absolute pressure to altitude (given baseline pressure; sea-level, runway, etc.)
				// P: absolute pressure (mbar), P0: fixed baseline pressure (mbar)
				// returns signed altitude in meters. 

				char readInt(char address, int &value);
				// read an signed int (16 bits) from a BMP180 register
				// address: BMP180 register address
				// value: external signed int for returned value (16 bits)
				// returns 1 for success, 0 for fail, with result in value

				char readUInt(char address, unsigned int &value);
				// read an unsigned int (16 bits) from a BMP180 register
				// address: BMP180 register address
				// value: external unsigned int for returned value (16 bits)
				// returns 1 for success, 0 for fail, with result in value

				char readBytes(unsigned char *values, char length);
				// read a number of bytes from a BMP180 register
				// values: array of char with register address in first location [0]
				// length: number of bytes to read back
				// returns 1 for success, 0 for fail, with read bytes in values[] array

				char writeBytes(unsigned char *values, char length);
				// write a number of bytes to a BMP180 register (and consecutive subsequent registers)
				// values: array of char with register address in first location [0]
				// length: number of bytes to write
				// returns 1 for success, 0 for fail
				
				char getError(void);
				//used to determine which errors the altimeter functions have returned

				//variables used by the i2C and calibration methods
				int AC1,AC2,AC3,VB1,VB2,MB,MC,MD;
				unsigned int AC4,AC5,AC6;
				float c5,c6,mc,md,x0,x1,x2,y0,y1,y2,p0,p1,p2;
				
				//variables used by begin and calibrate	
				int buttonPin, speakerPin, ledPin;
				float baselineSLP;
				char _error;

		};
				
};


#endif
